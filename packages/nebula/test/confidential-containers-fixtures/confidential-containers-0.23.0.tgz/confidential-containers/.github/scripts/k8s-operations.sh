#!/usr/bin/env bash
#
# Kubernetes Operations Script - Main Router
# Routes commands to specialized sub-scripts
#
# Usage: k8s-operations.sh CATEGORY COMMAND [OPTIONS]
#
# Run: k8s-operations.sh --help for full documentation

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

show_help() {
    cat << 'EOF'
Kubernetes Operations Script
All Kubernetes-related operations in one place

Usage: k8s-operations.sh CATEGORY COMMAND [OPTIONS]

Categories & Commands:

=== SETUP CATEGORY ===
  setup kubeadm [RUNTIME] [VERSION]
      Setup Kubernetes with kubeadm
      RUNTIME: containerd or crio (default: containerd)
      VERSION: containerd version for containerd runtime (default: latest)

  setup k3s [EXTRA_PARAMS]
      Setup K3s distribution

  setup k0s [EXTRA_PARAMS]
      Setup K0s distribution

  setup rke2
      Setup RKE2 distribution

  setup microk8s
      Setup MicroK8s distribution

=== POD CATEGORY ===
  pod verify-cluster-health
      Verify cluster health before running tests

  pod create POD_NAME RUNTIME_CLASS [NAMESPACE]
      Create a test pod with specified RuntimeClass

  pod wait POD_NAME [NAMESPACE] [TIMEOUT]
      Wait for pod to reach Running or Succeeded state

  pod check-status POD_NAME [NAMESPACE]
      Check and validate final pod status

  pod show-details POD_NAME [NAMESPACE]
      Show detailed information about a pod

  pod show-logs POD_NAME [NAMESPACE]
      Show logs from a pod

  pod verify-runtime POD_NAME RUNTIME_CLASS [NAMESPACE]
      Verify pod is using Kata runtime

  pod cleanup POD_NAME [NAMESPACE]
      Delete test pod

=== DEPLOYMENT CATEGORY ===
  deployment wait-daemonset [OPTIONS]
      Wait for the kata-deploy install to complete
      Options:
        --namespace NAME          Namespace (default: coco-system)
        --label SELECTOR          Label selector (default: name=kata-as-coco-runtime)
        --timeout TIME            Timeout (default: 15m)
        --deployment-mode MODE    daemonset or job (default: daemonset). In job
                                  mode there is no always-on DaemonSet, so this
                                  waits for a node to gain the kata-runtime label.

  deployment verify-daemonset [OPTIONS]
      Verify the kata-deploy install status
      Options:
        --namespace NAME          Namespace (default: coco-system)
        --label SELECTOR          Label selector (default: name=kata-as-coco-runtime)
        --deployment-mode MODE    daemonset or job (default: daemonset)

  deployment show-logs [OPTIONS]
      Show kata-deploy logs
      Options:
        --namespace NAME          Namespace (default: coco-system)
        --label SELECTOR          Label selector (default: name=kata-as-coco-runtime)
        --tail LINES              Number of lines (default: 50)
        --deployment-mode MODE    daemonset or job (default: daemonset)

  deployment verify-runtimeclasses RUNTIMECLASS [RUNTIMECLASS...]
      Verify RuntimeClasses exist
      Options:
        --timeout SECONDS         Timeout in seconds (default: 180)

  deployment show-runtimeclass-details RUNTIMECLASS [RUNTIMECLASS...]
      Show RuntimeClass details

=== CLEANUP CATEGORY ===
  cleanup kubeadm
      Cleanup kubeadm cluster and all components

  cleanup k3s
      Cleanup K3s distribution

  cleanup k0s
      Cleanup K0s distribution

  cleanup rke2
      Cleanup RKE2 distribution

  cleanup microk8s
      Cleanup MicroK8s distribution
EOF
}

if [ $# -lt 1 ] || [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    show_help
    exit 0
fi

if [ $# -lt 2 ]; then
    echo "Usage: $0 CATEGORY COMMAND [OPTIONS]"
    echo ""
    echo "Categories:"
    echo "  setup       - Setup Kubernetes distributions"
    echo "  pod         - Pod operations"
    echo "  deployment  - Deployment verification"
    echo "  cleanup     - Cleanup Kubernetes clusters and components"
    echo ""
    echo "Run '$0 --help' for detailed help"
    exit 1
fi

CATEGORY="$1"
COMMAND="$2"
shift 2

# Route to appropriate sub-script
case "${CATEGORY}" in
    setup)
        exec "${SCRIPT_DIR}/k8s-setup.sh" "${COMMAND}" "$@"
        ;;
    pod)
        exec "${SCRIPT_DIR}/k8s-pod-operations.sh" "${COMMAND}" "$@"
        ;;
    deployment)
        exec "${SCRIPT_DIR}/k8s-deployment-verification.sh" "${COMMAND}" "$@"
        ;;
    cleanup)
        exec "${SCRIPT_DIR}/k8s-cleanup.sh" "${COMMAND}" "$@"
        ;;
    *)
        echo "Unknown category: ${CATEGORY}"
        echo "Available categories: setup, pod, deployment, cleanup"
        echo "Run '$0 --help' for detailed help"
        exit 1
        ;;
esac
